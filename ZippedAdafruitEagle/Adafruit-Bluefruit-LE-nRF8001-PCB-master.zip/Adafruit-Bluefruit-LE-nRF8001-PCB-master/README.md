Adafruit-Bluefruit-LE-nRF8001-PCB
=================================

These are the PCB files for Adafruit Bluefruit LE nRF8001 PCB
Format is EagleCAD schematic and board layout

For more details, check out the product page at

-----> https://www.adafruit.com/product/1697

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution